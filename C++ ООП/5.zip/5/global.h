#ifndef LIB_GL
#define LIB_GL


void clearbuf();
int check_int_input(int *i);
int input_and_check(char *s,char str[]);
void print_do();
void print_import();


#endif