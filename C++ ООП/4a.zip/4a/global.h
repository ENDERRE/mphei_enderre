
#ifndef LIB_G
#define LIB_G

#include <stdio.h>


void clearbuf();
int check_int_input(int *i);
int input_and_check(char *s,char str[]);
int check_int_input_file(int *i,FILE* file);
void print_do();



#endif
